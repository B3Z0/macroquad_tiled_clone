// spatial/mod.rs
pub mod index;
pub use index::*;
